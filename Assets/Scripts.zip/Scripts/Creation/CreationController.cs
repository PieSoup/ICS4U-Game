using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreationController : MonoBehaviour
{
    private bool touchedLastFrame = false;
    private Vector3 lastTouchPos = new Vector3();

    private ElementType selectedElementType = ElementType.WATER;
    private BRUSHTYPE brushType = BRUSHTYPE.CIRCLE;
    private int brushSize = 10;
    private readonly int maxBrushSize = 50;
    private readonly int minBrushSize = 3;

    Dictionary<KeyCode, ElementType> keyMap;

    [SerializeField] private ElementMatrix matrix;

    private void Awake() {
        keyMap = new Dictionary<KeyCode, ElementType>();
        keyMap.Add(KeyCode.Alpha1, ElementType.EMPTYCELL);
        keyMap.Add(KeyCode.Alpha2, ElementType.STONE);
        keyMap.Add(KeyCode.Alpha3, ElementType.SAND);
        keyMap.Add(KeyCode.Alpha4, ElementType.WATER);
    }

    private void Update() {
        if(Input.GetMouseButton(0)) {
            SpawnElementByInput();
        }
        else {
            touchedLastFrame = false;
        }

        SetSelectedElementType();
        SetBrushSize(Input.mouseScrollDelta);
    }

    private void SetSelectedElementType() {
        foreach(KeyCode keyCode in keyMap.Keys) {
            if(Input.GetKeyDown(keyCode)) {
                ElementType elementType;
                if(keyMap.TryGetValue(keyCode, out elementType)) {
                    selectedElementType = elementType;
                }
            }
        }
    }

    private void SetBrushSize(Vector2 brushDelta) {
        brushSize += (int) brushDelta.y;
        if(brushSize > maxBrushSize) {
            brushSize = maxBrushSize;
        }
        else if(brushSize < minBrushSize) {
            brushSize = minBrushSize;
        }
    }

    private void SpawnElementByInput() {
        Vector3 touchPos;
        touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        if(touchedLastFrame) {
            matrix.SpawnElementBetweenTwoPoints(lastTouchPos, touchPos, selectedElementType, brushSize, brushType);
        }
        else {
            matrix.SpawnElementByPixelWithBrush(touchPos.x, touchPos.y, selectedElementType, brushSize, brushType);
        }

        lastTouchPos = touchPos;
        touchedLastFrame = true;
    }
    public enum BRUSHTYPE {
        CIRCLE,
        SQUARE,
        RECTANGLE
    }
}
