using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGenerator : MonoBehaviour
{
    private Element[,] matrix;

    public int sizeX {private get; set;}
    public int sizeY {private get; set;}

    [SerializeField] private string seed;
    [SerializeField] private bool useRandomSeed;
    [Range(0, 100)]
    [SerializeField] private int randomFillPercent;

    public Element[,] GenerateMatrix() {

        matrix = new Element[sizeX,sizeY];
        RandomFillMatrix();

        for (int i = 0; i < 5; i++)
        {
            SmoothMap();
        }
        return matrix;
    }

    private void RandomFillMatrix() {
        
        if (useRandomSeed) {
            seed = Time.time.ToString();
        }

        System.Random pseudoRandom = new System.Random(seed.GetHashCode());

        for (int y = 0; y < sizeY; y++)
        {
            for (int x = 0; x < sizeX; x++)
            {
                if (x == 0 || x == sizeX - 1 || y == 0 || y == sizeY - 1){
                    matrix[x,y] = ElementType.STONE.CreateElementByMatrix(x, y);
                }
                else{
                    if (pseudoRandom.Next(0,100) < randomFillPercent) {
                        matrix[x,y] = ElementType.STONE.CreateElementByMatrix(x, y);
                    }
                    else {
                        matrix[x,y] = ElementType.EMPTYCELL.CreateElementByMatrix(x, y);
                    }
                }
            }
        }
    }

    private void SmoothMap() {
        int[,] neighbourWallTiles = new int[sizeX,sizeY];
        for (int y = 0; y < sizeY; y++)
        {
            for (int x = 0; x < sizeX; x++)
            {
                neighbourWallTiles[x,y] = GetSurroundingElementCount(x, y, 20);
            }
        }

        for (int y = 0; y < sizeY; y++)
        {
            for (int x = 0; x < sizeX; x++)
            {
                if (neighbourWallTiles[x,y] > 840) {
                    matrix[x,y] = ElementType.STONE.CreateElementByMatrix(x, y);
                }
                else if (neighbourWallTiles[x,y] < 840) {
                    matrix[x,y] = ElementType.EMPTYCELL.CreateElementByMatrix(x, y);
                }
            }
        }
    }

    private int GetSurroundingElementCount(int x, int y, int distance) {

        int elementCount = 0;
        for (int neighbourX = x - distance; neighbourX <= x + distance; neighbourX++)
        {
            for (int neighbourY = y - distance; neighbourY <= y + distance; neighbourY++)
            {
                if(neighbourX >= 0 && neighbourX < sizeX && neighbourY >= 0 && neighbourY < sizeY) {
                    if(neighbourX != x || neighbourY != y) {
                        elementCount += matrix[neighbourX,neighbourY].elementType == ElementType.STONE ? 1 : 0;
                    }
                }
                else {
                    elementCount++;
                }
            }
        }
        return elementCount;
    }
}
