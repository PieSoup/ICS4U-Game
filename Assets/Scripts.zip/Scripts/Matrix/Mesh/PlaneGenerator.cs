using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaneGenerator : MonoBehaviour
{

    private MeshFilter meshFilter;

    [Header("Dimensions:")]
    [SerializeField] private int sizeX;
    [SerializeField] private int sizeY;

    public int SizeX {get{return sizeX;}}
    public int SizeY {get{return sizeY;}}

    private Plane plane;

    private void Awake() {
        TryGetComponent(out meshFilter);
    }

    private void Start() {

        if(meshFilter) {
            plane = new Plane(meshFilter.mesh, sizeX+1, sizeY+1);
        }
    }
}

public abstract class ProdeduralShape {

    protected Mesh mesh;
    protected Vector3[] vertices;
    protected int[] triangles;
    protected Vector2[] uvs;

    public ProdeduralShape(Mesh mesh) {
        this.mesh = mesh;
    }
}

public class Plane : ProdeduralShape {

    private int sizeX, sizeY;

    public Plane(Mesh mesh, int sizeX, int sizeY) : base(mesh) {

        this.sizeX = sizeX;
        this.sizeY = sizeY;
        CreateMesh();

    }

    private void CreateMesh() {

        CreateVertices();
        CreateTriangles();
        ScaleMesh((1f/16f));
        CreateUVs();

        mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.uv = uvs;

    }

    private void CreateVertices() {

        vertices = new Vector3[sizeX * sizeY];

        for (int y = 0; y < sizeY; y++)
        {
            for (int x = 0; x < sizeX; x++)
            {
                vertices[x + y * sizeX] = new Vector3(x, y);
            }
        }
    }

    private void CreateTriangles() {

        triangles = new int[3*2*(sizeX * sizeY - sizeX - sizeY + 1)];

        int triangleVertexCount = 0;

        for(int vertex = 0; vertex < sizeX * sizeY - sizeX; vertex++) {

            if(vertex % sizeX != (sizeX - 1)){

                int A = vertex;
                int B = A + sizeX;
                int C = B + 1;

                triangles[triangleVertexCount] = A;
                triangles[triangleVertexCount + 1] = B;
                triangles[triangleVertexCount + 2] = C;
                
                B += 1;
                C = A + 1;

                triangles[triangleVertexCount + 3] = A;
                triangles[triangleVertexCount + 4] = B;
                triangles[triangleVertexCount + 5] = C;

                triangleVertexCount += 6;
            }
        }
    }

    private void CreateUVs() {

        uvs = new Vector2[sizeX * sizeY];
        int uvIndexCounter = 0;
        foreach(Vector3 vertex in vertices){
            uvs[uvIndexCounter] = new Vector2(vertex.x / ((sizeX-1) / 16), vertex.y / ((sizeY-1f) / 16f));
            uvIndexCounter++;
        }
    }

    private void ScaleMesh(float scaleFactor) {

        for (int i = 0; i < vertices.Length; i++)
        {
            vertices[i] *= scaleFactor;
        }
    }
}
