using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class ElementMatrix : MonoBehaviour
{
    
    public Element[,] matrix {get; set;}

    private PlaneGenerator plane;
    private MeshFilter meshFilter;

    private MapGenerator mapGenerator;

    public int sizeX {get; private set;}
    public int sizeY {get; private set;}

    [SerializeField] private Material planeMaterial;
    private Texture2D texture;

    private List<int> shuffledXIndexes;

    public static BitArray stepped = new BitArray(1);
    public static Vector3 gravity = new Vector3(0f, -5f, 0f);
    
    private void Awake() {
        TryGetComponent(out meshFilter);
        
        plane = GetComponent<PlaneGenerator>();
        meshFilter.GetComponent<Renderer>().material = planeMaterial;

        mapGenerator = GetComponent<MapGenerator>();
    }

    private void Start() {

        sizeX = plane.SizeX;
        sizeY = plane.SizeY;

        mapGenerator.sizeX = sizeX;
        mapGenerator.sizeY = sizeY;

        texture = new Texture2D(sizeX, sizeY);
        texture.filterMode = FilterMode.Point;
        planeMaterial.mainTexture = texture;

        matrix = new Element[sizeX,sizeY];
        matrix = mapGenerator.GenerateMatrix();

        shuffledXIndexes = GenerateShuffledXIndexes(sizeX);

        stepped.Set(0, true);
    }

    private void Update() {
        DrawTexture();
    }
    private void FixedUpdate() {
        stepped.Set(0, !stepped.Get(0));
        ReshuffleXIndexes();
        StepAll();
    }

    private void StepAll() {
        for(int y = 0; y < sizeY; y++) {
            foreach(int x in shuffledXIndexes) {
                Element element = matrix[x, y];
                element.Step(this);
            }
        }
    }

    private void ReshuffleXIndexes() {
        System.Random rand = new System.Random();
        shuffledXIndexes = shuffledXIndexes.OrderBy(_ => rand.Next()).ToList();

    }

    private List<int> GenerateShuffledXIndexes(int size) {
        List<int> list = new List<int>(size);
        for(int i = 0; i < size; i++) {
            list.Add(i);
        }
        return list;
    }

    public int ToMatrix(int val) {
        return val * 16;
    }

    public int ToMatrix(float val) {
        return Mathf.RoundToInt(val * 16f);
    }

    public void SpawnElementByPixelWithBrush(float pixelX, float pixelY, ElementType elementType, int brushSize, CreationController.BRUSHTYPE brushType) {

        int matrixX = ToMatrix(pixelX);
        int matrixY = ToMatrix(pixelY);

        SpawnElementByMatrixWithBrush(matrixX, matrixY, elementType, brushSize, brushType);
    }

    private void SpawnElementByMatrixWithBrush(int matrixX, int matrixY, ElementType elementType, int brushSize, CreationController.BRUSHTYPE brushType) {

        int halfBrush = Mathf.FloorToInt(brushSize / 2);

        for(int x = matrixX - halfBrush; x <= matrixX + halfBrush; x++) {
            for(int y = matrixY - halfBrush; y <= matrixY + halfBrush; y++) {
                if(brushType.Equals(CreationController.BRUSHTYPE.CIRCLE)) {
                    
                    int distance = Helpers.DistanceBetweenTwoPoints(matrixX, x, matrixY, y);

                    if(distance < halfBrush) {
                        SpawnElementByMatrix(x, y, elementType);
                    }
                }
                else {
                    SpawnElementByMatrix(x, y, elementType);
                }
            }
        }
    }

    public void SpawnElementByMatrix(int x, int y, ElementType elementType) {
        if(!isWithinBounds(x, y)) return;
        SetElementAtIndex(x, y, elementType.CreateElementByMatrix(x, y));
    }

    public void SpawnElementBetweenTwoPoints(Vector3 pos1, Vector3 pos2, ElementType elementType, int brushSize, CreationController.BRUSHTYPE brushType) {
        
        int matrixX1 = ToMatrix(pos1.x);
        int matrixY1 = ToMatrix(pos1.y);
        int matrixX2 = ToMatrix(pos2.x);
        int matrixY2 = ToMatrix(pos2.y);

        if(Helpers.EpsilonEquals(pos1, pos2, 0.01f)) { 
            SpawnElementByMatrixWithBrush(matrixX1, matrixY1, elementType, brushSize, brushType);
            return;
        }

        int xDifference = matrixX2 - matrixX1;
        int yDifference = matrixY2 - matrixY1;

        bool xDifferenceIsLarger = Mathf.Abs(xDifference) > Mathf.Abs(yDifference);

        int xModifier = xDifference > 0 ? 1 : -1;
        int yModifier = yDifference > 0 ? 1 : -1;

        int max = Mathf.Max(Mathf.Abs(xDifference), Mathf.Abs(yDifference));
        int min = Mathf.Min(Mathf.Abs(xDifference), Mathf.Abs(yDifference));

        float slope = (min == 0 || max == 0) ? 0 : ((float) (min + 1) / (max + 1));

        int smallCount;

        for(int i = 1; i <= max; i++) {
            smallCount = Mathf.FloorToInt(i * slope);
            int xIncrease, yIncrease;

            if(xDifferenceIsLarger) {
                xIncrease = i;
                yIncrease = smallCount;
            }
            else {
                xIncrease = smallCount;
                yIncrease = i;
            }

            int currentX = matrixX1 + (xIncrease * xModifier);
            int currentY = matrixY1 + (yIncrease * yModifier);

            if(isWithinBounds(currentX, currentY)) {
                SpawnElementByMatrixWithBrush(currentX, currentY, elementType, brushSize, brushType);
            }
        }
    }

    public void SetElementAtIndex(int x, int y, Element newElement) {
        if(isWithinBounds(x, y)) {
            matrix[x, y] = newElement;
            newElement.SetCoordinatesByMatrix(x, y);
        }
    }

    public Element Get(int x, int y) {
        if(isWithinBounds(x, y)) {
            return matrix[x, y];
        }
        else {
            return null;
        }
    }

    public List<Element> GetElementsAroundVertex(float vertexX, float vertexY) {

        int x = ToMatrix(vertexX);
        int y = ToMatrix(vertexY);
        
        List<Element> cells = new List<Element>();
        if(isWithinBounds(x, y)) {
            cells.Add(Get(x, y));
        }

        if(isWithinBounds(x-1, y)) {
            cells.Add(Get(x-1, y));
        }

        if(isWithinBounds(x-1, y-1)) {
            cells.Add(Get(x-1, y-1));
        }

        if(isWithinBounds(x, y-1)) {
            cells.Add(Get(x, y-1));
        }

        return cells;
    }

    public bool isWithinBounds(int x, int y) {

        if(x >= 0 && x < sizeX && y >= 0 && y < sizeY) {
            return true;
        }
        return false;
    }

    private void DrawTexture() {

        Color[] colors = new Color[sizeX * sizeY];
        
        for (int y = 0; y < sizeY; y++)
        {
            for (int x = 0; x < sizeX; x++)
            {
                int index = y * sizeX + x;
                colors[index] = matrix[x,y].elementColor;
                
            }
        }

        texture.SetPixels(colors);
        texture.Apply();
    }
}