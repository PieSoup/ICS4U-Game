using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public static class ElementTypes {

    public static Element CreateElementByMatrix(this ElementType elementType, int x, int y) {
        switch (elementType) {

            case ElementType.EMPTYCELL: return EmptyCell.GetInstance();
            case ElementType.STONE: return new Stone(x, y);
            case ElementType.SAND: return new Sand(x, y);
            case ElementType.WATER: return new Water(x, y);

            default:
                throw new Exception("Unsupported element type");
        }
    }
}

public enum ElementType
{
    EMPTYCELL,
    STONE,
    SAND,
    WATER
}

public enum ClassType
{
    MOVEABLESOLID,
    IMMOVEABLESOLID,
    LIQUID,
    EMPTYCELL
}
