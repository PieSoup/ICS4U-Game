using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;

public class Water : Liquid
{
    public Water(int x, int y) : base(x, y) {

        elementColor = Color.blue;
        
        dispersionRate = 3;
        frictionFactor = 1f;
        velocity = new Vector3(0, -124f, 0);
    }
}
