using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sand : MovableSolid
{
    public Sand(int x, int y) : base(x, y) {

        elementColor = Color.yellow;
        
        velocity = new Vector3(Random.value > 0.5f ? -1 : 1, -124f, 0f);
        frictionFactor = 0.9f;
        inertialResistance = 0.1f;
    }
}
