using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stone : ImmovableSolid
{
    public Stone(int x, int y) : base(x, y) {
        elementColor = Color.grey;
    }
}
