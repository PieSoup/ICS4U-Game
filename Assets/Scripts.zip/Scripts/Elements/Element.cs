using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public abstract class Element
{

    public int matrixX {get; set;}
    public int matrixY {get; set;}
    public BitArray stepped = new BitArray(1);
    public bool isFreeFalling = true;
    public float inertialResistance;

    public ElementType elementType {get; private set;}
    public Color elementColor {get; set;}

    public Vector3 velocity;
    public float xThreshold = 0;
    public float yThreshold = 0;
    public float frictionFactor;

    public Element(int x, int y) {
        SetCoordinatesByMatrix(x, y);
        elementType = GetElementEnumType();

        stepped.Set(0, ElementMatrix.stepped.Get(0));
    }

    public void SetCoordinatesByMatrix(int x, int y) {
        matrixX = x;
        matrixY = y;
    }

    public ElementType GetElementEnumType() {
        return (ElementType)Enum.Parse(typeof(ElementType), GetType().Name.ToUpper());
    }

    public void SwapPositions(ElementMatrix matrix, Element toSwap, int toSwapX, int toSwapY) {
        if(matrixX == toSwapX && matrixY == toSwapY) {
            return;
        }

        matrix.SetElementAtIndex(matrixX, matrixY, toSwap);

        matrix.SetElementAtIndex(toSwapX, toSwapY, this);
    }

    public void MoveToLastValid(ElementMatrix matrix, Vector3 moveToLocation) {
        if((int) (moveToLocation.x) == matrixX && (int) (moveToLocation.y) == matrixY) return;

        Element toSwap = matrix.matrix[(int) moveToLocation.x, (int) moveToLocation.y];
        SwapPositions(matrix, toSwap, (int) moveToLocation.x, (int) moveToLocation.y);
    }

    public void MoveToLastValidAndSwap(ElementMatrix matrix, Element toSwap, int toSwapX, int toSwapY, Vector3 moveToPosition) {
        int movePosX = (int) moveToPosition.x;
        int movePosY = (int) moveToPosition.y;

        Element neighbour = matrix.matrix[movePosX, movePosY];

        if(this == neighbour || toSwap == neighbour) {
            SwapPositions(matrix, toSwap, toSwapX, toSwapY);
            return;
        }

        if(this == toSwap) {
            SwapPositions(matrix, neighbour, movePosX, movePosY);
            return;
        }

        matrix.SetElementAtIndex(matrixX, matrixY, neighbour);
        matrix.SetElementAtIndex(toSwapX, toSwapY, this);
        matrix.SetElementAtIndex(movePosX, movePosY, toSwap);
    }

    public abstract void Step(ElementMatrix matrix);

    protected abstract bool ActOnElementNeighbour(Element neighbour, int modifiedX, int modifiedY, ElementMatrix matrix, bool isFinal, bool isFirst, Vector3 lastValidLocation, int depth);
}
